using System;

public class Program
{
	public static void Main(String[] args)
	{
		Console.WriteLine("Hello World!!!");
	}
}
